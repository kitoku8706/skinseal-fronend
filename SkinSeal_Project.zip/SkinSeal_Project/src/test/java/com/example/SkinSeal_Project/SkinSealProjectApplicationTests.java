package com.example.SkinSeal_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkinSealProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
