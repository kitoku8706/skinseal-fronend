package com.example.SkinSeal_Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkinSealProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkinSealProjectApplication.class, args);
	}

}
